import { Users, Target, Award, Heart } from 'lucide-react';

export default function About() {
  return (
    <div className="min-h-screen pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
            About Our Studio
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We're a passionate team of creatives dedicated to transforming ideas into
            exceptional visual experiences that leave lasting impressions.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 mb-20">
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-gray-900">Our Story</h2>
            <p className="text-gray-600 leading-relaxed">
              Founded with a vision to bridge creativity and innovation, our studio has been
              helping brands tell their stories through compelling design and strategic thinking.
            </p>
            <p className="text-gray-600 leading-relaxed">
              We believe that great design is more than aesthetics—it's about creating
              meaningful connections between brands and their audiences. Every project we
              undertake is an opportunity to push boundaries and deliver excellence.
            </p>
          </div>

          <div className="bg-gradient-to-br from-blue-100 to-green-100 rounded-2xl h-80 flex items-center justify-center">
            <div className="text-center">
              <p className="text-6xl font-bold text-gray-800 mb-2">5+</p>
              <p className="text-gray-700 font-medium">Years of Excellence</p>
            </div>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          <div className="text-center p-6 bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="text-blue-600" size={32} />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">100+</h3>
            <p className="text-gray-600">Happy Clients</p>
          </div>

          <div className="text-center p-6 bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Target className="text-green-600" size={32} />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">250+</h3>
            <p className="text-gray-600">Projects Completed</p>
          </div>

          <div className="text-center p-6 bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Award className="text-orange-600" size={32} />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">15+</h3>
            <p className="text-gray-600">Awards Won</p>
          </div>

          <div className="text-center p-6 bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="text-red-600" size={32} />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">100%</h3>
            <p className="text-gray-600">Client Satisfaction</p>
          </div>
        </div>

        <div className="bg-gray-900 rounded-2xl p-12 text-center text-white">
          <h2 className="text-3xl font-bold mb-6">Our Values</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div>
              <h3 className="text-xl font-bold mb-3">Innovation</h3>
              <p className="text-gray-300">
                We constantly explore new ideas and push creative boundaries.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-3">Excellence</h3>
              <p className="text-gray-300">
                Quality is at the heart of everything we create and deliver.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-3">Collaboration</h3>
              <p className="text-gray-300">
                We work closely with our clients as partners in success.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
